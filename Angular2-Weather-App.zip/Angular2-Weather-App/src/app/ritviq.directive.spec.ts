import { RitviqDirective } from './ritviq.directive';

describe('RitviqDirective', () => {
  it('should create an instance', () => {
    const directive = new RitviqDirective();
    expect(directive).toBeTruthy();
  });
});
