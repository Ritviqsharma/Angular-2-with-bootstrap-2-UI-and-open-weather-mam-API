import { Directive } from '@angular/core';

@Directive({
  selector: '[waRitviq]'
})
export class RitviqDirective {

  constructor() { }

}
