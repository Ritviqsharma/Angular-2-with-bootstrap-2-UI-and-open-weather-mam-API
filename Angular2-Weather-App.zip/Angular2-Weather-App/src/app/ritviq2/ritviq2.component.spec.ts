import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Ritviq2Component } from './ritviq2.component';

describe('Ritviq2Component', () => {
  let component: Ritviq2Component;
  let fixture: ComponentFixture<Ritviq2Component>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ Ritviq2Component ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Ritviq2Component);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
