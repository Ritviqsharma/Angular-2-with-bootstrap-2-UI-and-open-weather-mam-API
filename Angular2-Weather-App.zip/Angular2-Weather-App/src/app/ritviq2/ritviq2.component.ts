import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'wa-ritviq2',
  templateUrl: './ritviq2.component.html',
  styleUrls: ['./ritviq2.component.css']
})
export class Ritviq2Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
